import '../data/activity_data.dart';
import '../models/activity_model.dart';

/// REPOSITORY: mengelola akses & manipulasi data (CRUD).
class ActivityRepository {
  final ActivityData _data;

  ActivityRepository(this._data);

  /// Mengambil seluruh aktivitas.
  List<ActivityModel> getAll() => List.unmodifiable(_data.activities);

  /// Mengambil satu aktivitas berdasarkan ID.
  ActivityModel? getById(int id) {
    return _data.activities.where((a) => a.id == id).firstOrNull;
  }

  /// Menambahkan aktivitas baru.
  void add(String name) {
    _data.activities.add(
      ActivityModel(id: _data.generateId(), name: name),
    );
  }

  /// Mengubah nama aktivitas.
  void update(int id, String name) {
    final index = _data.activities.indexWhere((a) => a.id == id);
    if (index == -1) return;
    _data.activities[index] = _data.activities[index].copyWith(name: name);
  }

  /// Memperbarui nilai counter.
  void updateCounter(int id, int counter) {
    final index = _data.activities.indexWhere((a) => a.id == id);
    if (index == -1) return;
    _data.activities[index] =
        _data.activities[index].copyWith(counter: counter);
  }

  /// Menghapus aktivitas.
  void delete(int id) {
    _data.activities.removeWhere((a) => a.id == id);
  }
}