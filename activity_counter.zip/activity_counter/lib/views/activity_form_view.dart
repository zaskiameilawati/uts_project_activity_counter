import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/activity_viewmodel.dart';

/// VIEW: Halaman Tambah / Edit aktivitas.
/// Jika [activityId] null -> mode tambah, jika ada -> mode edit.
class ActivityFormView extends StatefulWidget {
  final int? activityId;

  const ActivityFormView({super.key, this.activityId});

  @override
  State<ActivityFormView> createState() => _ActivityFormViewState();
}

class _ActivityFormViewState extends State<ActivityFormView> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();

  bool get _isEdit => widget.activityId != null;

  @override
  void initState() {
    super.initState();
    if (_isEdit) {
      final activity =
          context.read<ActivityViewModel>().getById(widget.activityId!);
      _nameController.text = activity?.name ?? '';
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final viewModel = context.read<ActivityViewModel>();
    final messenger = ScaffoldMessenger.of(context);
    final name = _nameController.text;

    if (_isEdit) {
      viewModel.updateActivity(widget.activityId!, name);
    } else {
      viewModel.addActivity(name);
    }

    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(_isEdit
            ? 'Aktivitas berhasil diubah'
            : 'Aktivitas berhasil ditambahkan'),
      ),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEdit ? 'Edit Aktivitas' : 'Tambah Aktivitas'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameController,
                autofocus: true,
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(
                  labelText: 'Nama Aktivitas',
                  hintText: 'Contoh: Push Up',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Nama aktivitas tidak boleh kosong';
                  }
                  return null;
                },
                onFieldSubmitted: (_) => _save(),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save),
                label: const Text('Simpan'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}