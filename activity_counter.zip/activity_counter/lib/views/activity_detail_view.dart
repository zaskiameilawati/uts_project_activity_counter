import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/activity_viewmodel.dart';
import 'activity_form_view.dart';

/// VIEW: Halaman Detail aktivitas (counter, reset, hapus).
class ActivityDetailView extends StatelessWidget {
  final int activityId;

  const ActivityDetailView({super.key, required this.activityId});

  void _showSnack(BuildContext context, String message) {
    final messenger = ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  Future<void> _confirmReset(BuildContext context, String name) async {
    final viewModel = context.read<ActivityViewModel>();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset Counter'),
        content: Text('Yakin ingin mengembalikan counter "$name" ke 0?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );

    if (confirm == true && context.mounted) {
      viewModel.reset(activityId);
      _showSnack(context, 'Counter berhasil di-reset ke 0');
    }
  }

  Future<void> _confirmDelete(BuildContext context, String name) async {
    final viewModel = context.read<ActivityViewModel>();
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Aktivitas'),
        content: Text('Yakin ingin menghapus aktivitas "$name"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      navigator.pop(); // kembali ke Home dulu
      viewModel.deleteActivity(activityId);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        const SnackBar(content: Text('Aktivitas berhasil dihapus')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<ActivityViewModel>();
    final activity = viewModel.getById(activityId);

    // Pengaman jika aktivitas sudah terhapus.
    if (activity == null) {
      return const Scaffold(body: SizedBox.shrink());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Aktivitas'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            tooltip: 'Edit',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ActivityFormView(activityId: activity.id),
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              activity.name,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            Container(
              width: 180,
              height: 180,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Theme.of(context).colorScheme.primaryContainer,
              ),
              child: Text(
                '${activity.counter}',
                style: const TextStyle(fontSize: 64, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton.filled(
                  iconSize: 36,
                  tooltip: 'Kurang',
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    final ok = viewModel.decrement(activity.id);
                    _showSnack(
                      context,
                      ok
                          ? 'Counter berkurang menjadi ${activity.counter - 1}'
                          : 'Counter tidak boleh kurang dari 0',
                    );
                  },
                ),
                const SizedBox(width: 32),
                IconButton.filled(
                  iconSize: 36,
                  tooltip: 'Tambah',
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    viewModel.increment(activity.id);
                    _showSnack(
                      context,
                      'Counter bertambah menjadi ${activity.counter + 1}',
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: () => _confirmReset(context, activity.name),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reset'),
                ),
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: () => _confirmDelete(context, activity.name),
                  icon: const Icon(Icons.delete),
                  label: const Text('Hapus'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}