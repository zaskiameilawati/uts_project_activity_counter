import '../models/activity_model.dart';

/// DATA: sumber data. Menyimpan daftar aktivitas sementara di List
/// selama aplikasi berjalan.
class ActivityData {
  final List<ActivityModel> activities = [
    const ActivityModel(id: 1, name: 'Push Up', counter: 10),
    const ActivityModel(id: 2, name: 'Sit Up', counter: 5),
    const ActivityModel(id: 3, name: 'Lari Pagi', counter: 2),
  ];

  int _nextId = 4;

  /// Menghasilkan ID unik untuk aktivitas baru.
  int generateId() => _nextId++;
}