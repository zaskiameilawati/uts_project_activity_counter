import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/activity_data.dart';
import '../repositories/activity_repository.dart';
import '../viewmodels/activity_viewmodel.dart';
import '../views/home_view.dart';

void main() {
  runApp(
    // Menyediakan ViewModel ke seluruh halaman.
    // Alur pembuatan: Data -> Repository -> ViewModel
    ChangeNotifierProvider(
      create: (_) => ActivityViewModel(
        ActivityRepository(ActivityData()),
      ),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Activity Counter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
      ),
      home: const HomeView(),
    );
  }
}