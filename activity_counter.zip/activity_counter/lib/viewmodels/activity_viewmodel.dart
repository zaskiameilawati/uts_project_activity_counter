import 'package:flutter/foundation.dart';

import '../models/activity_model.dart';
import '../repositories/activity_repository.dart';

/// VIEWMODEL: logika aplikasi & state.
/// Memberi tahu View (notifyListeners) saat data berubah.
class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository;

  ActivityViewModel(this._repository);

  /// Meminta seluruh data dari Repository.
  List<ActivityModel> get activities => _repository.getAll();

  ActivityModel? getById(int id) => _repository.getById(id);

  void addActivity(String name) {
    _repository.add(name.trim());
    notifyListeners();
  }

  void updateActivity(int id, String name) {
    _repository.update(id, name.trim());
    notifyListeners();
  }

  void deleteActivity(int id) {
    _repository.delete(id);
    notifyListeners();
  }

  /// Menambah counter sebanyak 1.
  void increment(int id) {
    final activity = _repository.getById(id);
    if (activity == null) return;
    _repository.updateCounter(id, activity.counter + 1);
    notifyListeners();
  }

  /// Mengurangi counter sebanyak 1. Mengembalikan false jika sudah 0
  /// (counter tidak boleh kurang dari 0).
  bool decrement(int id) {
    final activity = _repository.getById(id);
    if (activity == null || activity.counter <= 0) return false;
    _repository.updateCounter(id, activity.counter - 1);
    notifyListeners();
    return true;
  }

  /// Mengembalikan counter ke 0.
  void reset(int id) {
    _repository.updateCounter(id, 0);
    notifyListeners();
  }
}